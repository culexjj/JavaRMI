package uned.sidi.distribuidor;

import java.rmi.ConnectException;
import java.rmi.NoSuchObjectException;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

import uned.sidi.comun.CallBackClienteInterface;
import uned.sidi.comun.Menu;
import uned.sidi.comun.ServicioAutenticacionInterface;
import uned.sidi.comun.ServicioMercanciasInterface;
import uned.sidi.comun.ServicioVentaInterface;




public class Distribuidor {

	/*--------------------------*/
	/* DECLARACION DE VARIABLES */
	/*--------------------------*/
	
	private static ServicioAutenticacionInterface servicioAutenticacion; //Objeto remoto Servicio de autenticación
	private static ServicioMercanciasInterface servicioMercancias; //Objeto remoto Servicio de mercancias
	private static CallBackClienteInterface callBackCliente; //Objeto remoto call back del cliente
	private static ServicioVentaInterface servicioVenta; //Objeto remoto Servicio de Ventas
	private static int IDSesion;//Identificador Único
	private static int tipo = 0; //Se usa para la clasificación de clientes y distribuidores. si tipo es 0 entonces indica que es un distribuidor y si es 1 indica que es un cliente
	private static int puerto = 9999; //Número de puerto de escucha del enlazador
	private static boolean registrado = false;//Variable de control para identificar registros previos
	private static boolean login = false;//Variable de control para identificar cuando el usuario ha realizado log in en el sistema y pasar al menu numero 2
	private static boolean activo = false; ////Variable de control para identificar si el usuario esta actualmente logeado en el sistema y evitar que otro cliente pueda iniciar sesion con los mismos datos
	private static Registry registro; //Registro 
	private static String nombreServicioVenta; //Nombre usado para registrar el servicio de ventas	
	private static String direccion = "localhost"; //host
	//private static String ip = "192.168.1.114"; //host
	
		

	public static void main(String[] args) throws RemoteException {
		
		String URLRegistroSAutenticacion; //Url completa servicio autenticación
		String URLRegistroSMercancias; //Url completa servicio mercancias
		
		/* Obtenemos el enlazador y localizamos los objetos remotos	*/	
		try{
			Registry registro = LocateRegistry.getRegistry(puerto); //Localizamos el enlazador en el puerto 9999
			URLRegistroSAutenticacion = "rmi://" + direccion + ":" + puerto + "/ServicioAutenticacion";
			URLRegistroSMercancias = "rmi://" + direccion + ":" + puerto + "/ServicioMercancias";
			servicioAutenticacion = (ServicioAutenticacionInterface) registro.lookup(URLRegistroSAutenticacion);
			servicioMercancias = (ServicioMercanciasInterface) registro.lookup(URLRegistroSMercancias);
		} catch(RemoteException e) {System.out.println(e.getMessage());
		} catch(Exception e) {System.out.println(e.getMessage());
		}
		
		System.out.println("Distribuidor Listo");

		/* Menu numero 1 */
		do{
			int valor = Menu.menu1();			
			switch (valor) {
	        case 1:
	            registrar(); 
	            break;
	        case 2:
	            autenticar();
	            break;
	        case 3:
	        	System.out.println("Salir");
        		System.exit(0);
		        break;
	        default: //Error (exit code 1)
	        	System.out.println("Error exit code = 1");
	        	System.exit(1);
			}
		} while (!login);
		
		/* Menu numero 2 */
		do{
			int valor = Menu.menu2(tipo);			
			switch (valor) {
	        case 1:
	            introducirOferta();
	            break;
	        case 2:
	        	eliminarOferta();
	            break;
			case 3:
				mostrarVentas();
	            break;
			case 4:
	            bajaSistema();
	            break;	
			case 5:
				servicioAutenticacion.salir(IDSesion); //Ponemos flag activo a false para permitir que se pueda iniciar otra sesion
				System.out.println("Salir");
		        System.exit(0);
				break;		        
	        default: //Error (exit code 2)
	        	System.out.println("Error exit code = 2");
	        	System.exit(2);
			}
		} while (true);		
	}

	
	/*--------------------------*/
	/*    METODOS   ESTATICOS   */
	/*--------------------------*/
		
	/**
	 * Registramos un nuevo distribuidor en el sistema. proporcionamos el nombre de usuario y la clave de acceso
	 * y obtenemos el ID asignado por el servicio de autenticación
	 * Se controlan registros previos (en la misma sesion) para evitar que se pueda registrar un distribuidor ya registrado
	 
	 */
	private static void registrar() {
		
		if (registrado) { //Si ya esta registrado se informa de los datos de acceso y se indica que ya esta registrado
			System.out.println("USUARIO YA REGISTRADO!!!");
			System.out.println("Su sesion es: " + IDSesion);	
			try {
				System.out.println("Su nombre de usuario es: " + servicioAutenticacion.getDatosNombre(IDSesion));
				System.out.println("Su clave de acceso es: " + servicioAutenticacion.getDatosClave(IDSesion));
			} catch(RemoteException e) {System.out.println(e.getMessage());
			} catch(Exception e) {System.out.println(e.getMessage());
			}
		} else { //Si no esta registrado solicitamos datos registro
			try{
				String nombreUsuario= ""; //Nombre usuario
				String clave= ""; //Clave de acceso

				nombreUsuario = Menu.nombreUsuario(); //Preguntamos nombre usuario
			    clave  = Menu.claveAcceso(); //Preguntamos clave de acceso	
			    IDSesion = servicioAutenticacion.registro(nombreUsuario, clave, tipo);//Registramos el usuario en el servicio autenticacion y obtenemos el IDSesion
				registrado = true; //El cliente se ha registrado con exito
				
				/*Mostramos por pantalla los datos de registro*/
				System.out.println("Su sesion es: " + IDSesion);		
				System.out.println("Su nombre de usuario es: " + servicioAutenticacion.getDatosNombre(IDSesion));
				System.out.println("Su clave de acceso es: " + servicioAutenticacion.getDatosClave(IDSesion));
				
			} catch(RemoteException e) {System.out.println(e.getMessage());
			} catch(Exception e) {System.out.println(e.getMessage());
			}
		}		
	}

	
	/**
	 * Metodo encargado de solicitar la  validacoion del acceso de un distribuidor al sistema. Solicitamos  el nombre de usuario y la clave de acceso si el usario se ha registrado
	 * en la sesion activa (ya tenemos el IDSesion). Si el usario estaba registrado previamente pero no ha iniciado sesion, tambien solicitamos su IDSesion
	 * Una vez la sesion se ha validado se crea el servicio de venta asociado al distribuidor.
	 * Al ser un ejemplo académico se ha limitado el número de distribuidores a 100. Se podria ampliar
	 * modificando la linea  puertoProxy = 10240 + (tmp % N); donde N seria el número máximo de distribuidores
	 */
	private static  void autenticar() {
		
		String nombreUsuario= "";
		String clave= "";
		boolean check = false; //Inicializamos variable de control de login correcto
		int tmp = 0; //Variable usado para calcular el numero de puerto del proxy del servicio de ventas
		int puertoProxy=0; //Numero de puerto del proxy del servicio de venta
	
		if (registrado) { //Si se ha registrado en esta sesion ya conocemos el valor de IDSesion
			try{	
				try { //Verificamos si el usario tiene una sesion activa flag activo = true
					activo = servicioAutenticacion.getFlagActivo(IDSesion); 
					if (activo) {
						System.out.println ("Este usuario ya tiene una sesion activa!");
						return; //Si existe una sesion activa salimos
					}
				} catch (RemoteException e) {
					e.printStackTrace();
				}
				
				nombreUsuario = Menu.nombreUsuario(); //Preguntamos nombre usuario
			    clave  = Menu.claveAcceso(); //Preguntamos clave de acceso	
				check = servicioAutenticacion.login(IDSesion, nombreUsuario, clave, tipo); //Verificamos que la tupla nombre de usuario clave de acceso son correctas para el IDSesion de la sesion activa
								
				if (!check) { //Si no es correcto se informa del error
					System.out.println();
					System.out.println ("Datos incorrectos, intentelo de nuevo !");	
					return; //Si los datos no son correctos salimos
				} else {
					System.out.println ("Nombre de usuario y clave de acceso correctos!");
					login = true; //login correcto
					activo = true; //Sesion activa
				}
				
				/* Creamos el servicio de venta asociado al distribuidor */
				registro = LocateRegistry.getRegistry(puerto); //Obtenemos el enlazador
				servicioVenta = new ServicioVentaImpl(); //Creamos objeto remoto del Servicio Venta
				
				/* calculamos el numero de puerto escucha del proxy en funcion del IDSesion.  10240 + modulo 100 de IDSesion */				
				if (IDSesion<0) {
					tmp = IDSesion * -1; //No podemos seleccionar un puerto < 0
					puertoProxy = 10240 + (tmp % 100);
				} else {
					tmp = IDSesion;
					puertoProxy = 10240 + (tmp % 100);
				}
			
				Remote ServicioVentaRemote = UnicastRemoteObject.exportObject(servicioVenta,puertoProxy); //proxy escucha puerto = puertoProxy		
				nombreServicioVenta = "ServicioVenta" + IDSesion; //nombre usado para registrar el servicio
				registro.rebind(nombreServicioVenta, ServicioVentaRemote); //Registramos el objeto remoto Servicio de Autenticacion en el enlazador
				
			} catch(RemoteException e) {System.out.println(e.getMessage());
			} catch(Exception e) {System.out.println(e.getMessage());
			}
		} else { //No se ha registrado en esta sesion y por lo tanto no sabemos IDSesion
			try{								
				IDSesion = Menu.identificador(); ////Preguntamos el ID de usuario
				
				if (IDSesion == 0 ) { //Si el metodo anterior devuelve ID = 0 es por que el formato es incorrecto y por lo tanto no se debe seguir
					return; //Salimos
				}
				
				try { //Verificamos si el usario tiene una sesion activa flag activo = true
					activo = servicioAutenticacion.getFlagActivo(IDSesion); 
					if (activo) {
						System.out.println ("Este usuario ya tiene una sesion activa!");
						return; //Si existe una sesion activa salimos
					}
				} catch (RemoteException e) {
					e.printStackTrace();
				}
								
				nombreUsuario = Menu.nombreUsuario(); //Preguntamos nombre usuario
				clave  = Menu.claveAcceso(); //Preguntamos clave de acceso
				
				check = servicioAutenticacion.login(IDSesion, nombreUsuario, clave, tipo); //Verificamos que la tupla nombre de usuario clave de acceso son correctas para el IDSesion de la sesion activa
							
				if (!check) { //Si no es correcto se informa del error
					System.out.println();
					System.out.println ("Datos incorrectos, intentelo de nuevo !");
					return; //Si los datos no son correctos salimos
				} else {
					System.out.println ("Nombre de usuario y clave de acceso correctos!");
					login = true;//login correcto
					activo = true; //Sesion activa
				}
						
				
				/* Creamos el servicio de venta asociado al distribuidor */
				registro = LocateRegistry.getRegistry(puerto); //Obtenemos el enlazador
				servicioVenta = new ServicioVentaImpl(); //Creamos objeto remoto del Servicio Venta
				
				/* calculamos el numero de puerto escucha del proxy en funcion del IDSesion  10240 + modulo 100 de IDSesion */
				if (IDSesion<0) {
					tmp = IDSesion * -1; //No podemos seleccionar un puerto < 0
					puertoProxy = 10240 + (tmp % 100);
				} else {
					tmp = IDSesion;
					puertoProxy = 10240 + (tmp % 100);
				}
			
				Remote ServicioVentaRemote = UnicastRemoteObject.exportObject(servicioVenta,puertoProxy); //proxy escucha puerto = puertoProxy		
				nombreServicioVenta = "ServicioVenta" + IDSesion; //nombre usado para registrar el servicio
				registro.rebind(nombreServicioVenta, ServicioVentaRemote); //Registramos el objeto remoto Servicio de Autenticacion en el enlazador
			} catch(RemoteException e) {System.out.println(e.getMessage());
			} catch(Exception e) {System.out.println(e.getMessage());
			}
		}
	}
	
	

	/**
	 * Solicitamos las caracteristas de la nueva oferta. Una vez tenemos todos los detalles de la oferta se pasan al servicio
	 * de mercancias y se registra en lista de ofertas de este distribuidor. Finalmente se envia un mensaje a cada cliente que
	 * previamente ha resgistrado una demanda del mismo tipo que la oferta informando del registro de esta nueva oferta
	 * @throws RemoteException 
	 */
	private static void introducirOferta() throws RemoteException{
		
		String tipoMercancia = Menu.introducirTipo(); //Tipo de la mercancia
		double precio = Menu.precioOferta(); //Precio de la oferta
		int peso = Menu.pesoOferta(); //Peso de la oferta
		ArrayList<Integer> lista = null; //lista de clientes que han realizado una demanda del mismo tipo. 
		servicioMercancias.addOferta(IDSesion, tipoMercancia, precio, peso); //Añadimos la oferta en la BBDD del distribuidor
		
		/* Call back */
		try{
			lista = servicioMercancias.buscarDemanda(tipoMercancia); //Obtenemos una lista con los IDSesion de todos los clientes que tienen registrada una demanda con el mismo tipo de mercancia que la oferta que estamos a�adiendo
		} catch (ConnectException e){ System.out.println(e.getMessage());
			
		}
		
		
		Iterator<Integer> iterador = lista.iterator(); //Obtenemos un iterador de la lista avisando a los clientes del nuevo registro de la oferta
		while(iterador.hasNext()){
			int id = iterador.next(); //Obtenemos el IDSesion
			
			try{
				String nombre = "CallBack" + id; //Obtenemos el identificador del Servicio de callBack	
				callBackCliente = (CallBackClienteInterface) registro.lookup(nombre);
				callBackCliente.avisoRegistroOferta("El Distribuidor : " +  IDSesion + " ha registrado una oferta de : " + tipoMercancia ); //Mensaje Informativo al cliente
			} catch(RemoteException e) {System.out.println("");
			} catch(Exception e) {System.out.println("");
			}
			
		}
	}
	
	
	/**
	 * Obtenemos un listado de todas las ofertas de este distribuiddor(se controla que la lista no está vacía), las numeramos
	 * y mostramos los detalles de la mismas. Se solicita el número de oferta a eliminar y una vez verificado que la oferta existe
	 * se elimina de la lista de ofertas.
	 * @throws RemoteException 
	 */
	private static void eliminarOferta() throws RemoteException{
		
		ArrayList<String> listado = new ArrayList<String>(); //Lista con las ofertas del distribuidor				
		listado = servicioMercancias.listarOfertasToArray(IDSesion); //Obtenemos la informacion de las ofertas
		
		if (listado.isEmpty()){ //Si la lista esta vacia no hay ofertas registradas
			System.out.println("\nNo hay ofertas registradas");
			return; //Salimos
		} else {
			System.out.println("Listado ofertas"); //Cabecera del listado
		}
		
		imprimir(listado); //Imprimimos el listado por la consola
		
		int numero = Menu.numeroOferta(); //Preguntamos el numero de oferta a eliminar
		
		try { //Se controla que existe la entrada en la lista de ofertas
			servicioMercancias.quitarOfertas(IDSesion, numero-1); //ajustamos el numero de oferta a eliminar
		} catch (IndexOutOfBoundsException e){
			System.out.println("Numero de oferta incorrecto!");
		} 
	}
	
	
	
	/**
	 * Mostramos las ventas del distribuidor. Obtenemos las lista de ofertas vendidas
	 * Iteramos sobre ella y lo mostramos por consola. Se controla si la lista está vacía
	 * @throws RemoteException 
	 */
	private static void mostrarVentas() throws RemoteException{
		
		ArrayList<String> listado = new ArrayList<String>(); //Lista con las ofertas del distribuidor
		
		listado = servicioVenta.listarVentasToArray(IDSesion); //Obtenemso la informacion de las ofertas del distribuidor
				
		if (listado.isEmpty()){ //Si la lista esta vacia no hay ofertas registradas
			System.out.println("No hay ventas registradas"); 
			return;
		} else {
			System.out.println("Listado ventas"); //Cabecera del listado
		}
		
		imprimir(listado); //Imprimimos el listado por la consola
	}
	
	
	/**
	 * Método encargado de gestionar la baja de un distribuidor del sistema
	 * La operación no se puede deshacer por lo que solicitamos  confirmación antes de procesarla
	 * Una vez procesada la baja el programa termina. Tambien se eliminan todas las ofertas asociadas.
	 */
	private static void bajaSistema(){
		
		boolean controlBajaUsuario = false; //Variable que controla si el borrado del usuario en el servicio de autenticacion ha sido correcto. Si ha sido correcto procedemos a borrar sus ofertas
		
		try {		
			System.out.println ("Esta operacion no se puede deshacer, esta seguro? (Si/No).");
			String opcion = "";
			@SuppressWarnings("resource")
			Scanner escaner = new Scanner (System.in); //Creación de un objeto Scanner
			opcion = escaner.nextLine ().trim(); //eliminamos espacios en blanco
		
			if (opcion.equalsIgnoreCase("Si") ||opcion.equalsIgnoreCase("S")) {
				controlBajaUsuario = servicioAutenticacion.bajaSistema(IDSesion); //Damos de baja en el servicio de auntenticacion
				if (controlBajaUsuario) { 
					servicioMercancias.bajaSistema(IDSesion,tipo,controlBajaUsuario); //damos de baja sus ofertas si control == true
				}
	
				try {
				registro.unbind(nombreServicioVenta); //desregistramos el objeto remoto
				} catch(RemoteException e) {System.out.println(e.getMessage());
				} catch(Exception e) {System.out.println(e.getMessage());
				}
				
				try {
				UnicastRemoteObject.unexportObject(servicioVenta, true); //eliminamos el objeto remoto
				} catch (NoSuchObjectException e) {System.out.println(e.getMessage());
				}

				System.out.println("Distribuidor Apagado");
				System.exit(0); //Fin del programa (exit code 0)
			} else {
				System.out.println ("Operacion cancelada!");
			}
			
		} catch(RemoteException e) {System.out.println(e.getMessage());
		} catch(Exception e) {System.out.println(e.getMessage());
		}
	}
	
	
	/**
	 * Metodo encargado de imprimir con formato la lista de ofertas que se pasa como parametro
	 * @param lista. La lista de tipo string con lo datos a imprimir
	 */
	private static void imprimir(ArrayList<String> lista) {
		ArrayList<String> listado = lista; //Lista con las ofertas del distribuidor
		int size = listado.size(); //Variable para controlar el numero de iteraciones
		int numeroOferta = 1; //Numero de oferta
				
		/* Imprimos por la consola del cliente la informacion del listado de ofertas. Vamos controlando por la posicion de la lista que 
		 * infomacion se imprime para mantener el formato. La lista se ha creado con esta estructura Identificador[0] Tipo[1] Precio[2]
		 * Peso[3] Identificador[4] de esta forma podemos usar el operador modulo para elegir que valor imprimir según iteramos la lista */
		for (int i=0; i < size; i++){						
			if (i != 0 && i % 4 == 0){
				System.out.println(""); //Si no es la primera linea de la lista pero es una cabezera de linea saltamos a la siguiente linea
			}
			
			if (i % 4 == 0){ //si es una primera columna de la fila imprimimos numero de oferta e identificador 
				System.out.print(String.format("%8s %3s %10s %13s", "Oferta:", numeroOferta,  "  Identificador: ", listado.get(i) + "  "));
			}
			
			if (i % 4 == 1){ //Si es la segunda columna imprimimos el tipo de la oferta
				System.out.print(String.format("%6s %10s", " Tipo: ", listado.get(i) + "  "));
			}
			if (i % 4 == 2){ //Si es la tercera columna imprimimos el precio
				System.out.print(String.format("%9s %18s", " Precio: ", listado.get(i) + " Euros  "));
			}
				
			if (i % 4 == 3){ //Si es la cuarta columna imprmimos el peso
				System.out.print(String.format("%8s %14s", " Peso: ", listado.get(i) + " Kilos "));
			}
			
			if (i % 4 == 0){
				numeroOferta++; //cada 4 iteraciones incrementamos el numero de la oferta
			}
		}
		System.out.println("\n");
	}
}
