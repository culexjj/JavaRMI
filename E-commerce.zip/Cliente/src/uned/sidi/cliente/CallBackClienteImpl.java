package uned.sidi.cliente;

import java.rmi.RemoteException;
import java.sql.Timestamp;
import uned.sidi.comun.CallBackClienteInterface;



public class CallBackClienteImpl implements CallBackClienteInterface{
		
	/*--------------------------*/
	/*       CONSTRUCTORES      */
	/*--------------------------*/
	
	protected CallBackClienteImpl() throws RemoteException {
		super();
		
	}

	/*--------------------------*/
	/*    METODOS   PUBLICOS    */
	/*--------------------------*/
	
	/**
	 * Metodo encargado de mostrar el mensaje de callback en la consola del cliente
	 * Añadimos la hora del sistema para simplificar la lectura
	 * @param mensaje. El mensaje a imprimir en la consola del cliente
	 */
	public synchronized void avisoRegistroOferta(String mensaje){
	
		Timestamp fecha = new Timestamp(System.currentTimeMillis()); //Fecha actual del sistema
		String mensajeRet = fecha + " " + mensaje;
		System.out.println(mensajeRet);
	}
}
