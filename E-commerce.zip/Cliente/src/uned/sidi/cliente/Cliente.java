package uned.sidi.cliente;

import java.rmi.NoSuchObjectException;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;
import java.util.Scanner;


import uned.sidi.comun.Menu;
import uned.sidi.comun.ServicioAutenticacionInterface;
import uned.sidi.comun.ServicioMercanciasInterface;
import uned.sidi.comun.ServicioVentaInterface;
import uned.sidi.comun.CallBackClienteInterface;



public class Cliente {
	
	/*--------------------------*/
	/* DECLARACION DE VARIABLES */
	/*--------------------------*/
	
	private static ServicioAutenticacionInterface servicioAutenticacion; //Objeto remoto Servicio de autenticacion
	private static ServicioMercanciasInterface servicioMercancias; //Objeto remoto Servicio de mercancias
	private static ServicioVentaInterface ServicioVenta; //Objeto remoto Servicio de venta
	private static CallBackClienteInterface callBackCliente; //Objeto remoto call back
	private static int IDSesion; //identificador unico
	private static int tipo = 1; //Se usa para la clasificacion de clientes y distribuidores. si tipo es 0 entonces indica que es un distribuidor y si es 1 indica que es un cliente
	private static int puerto = 9999; //Número de puerto de escucha del enlazador
	private static boolean registrado = false; //Variable de control para identificar registros previos
	private static boolean login = false; //Variable de control para identificar si el usuario ha realizado log in en el sistema y por lo tanto accedemos al menu numero 2
	private static boolean activo = false; ////Variable de control para identificar si el usuario esta actualmente logeado en el sistema y evitar que otro cliente pueda iniciar sesion con los mismos datos
	private static Registry registro; //Registro
	private static String nombreCallBack; //Nombre usado para registrar el servicio de callBack
	private static String direccion = "localhost"; //host	
	//private static String ip = "192.168.1.114"; //new
	
	
	public static void main(String[] args) throws RemoteException{
		
		String URLRegistroSAutenticacion; //Url completa servicio autenticación
		String URLRegistroSMercancias; //Url completa servicio mercancias
			
		/* Obtenemos el enlazador y localizamos los objetos remotos */		
		try{
			URLRegistroSAutenticacion = "rmi://" + direccion + ":" + puerto + "/ServicioAutenticacion";
			URLRegistroSMercancias = "rmi://" + direccion + ":" + puerto + "/ServicioMercancias";
			//Registry registro = LocateRegistry.getRegistry(ip, puerto); //Localizamos el enlazador en el puerto 9999
			Registry registro = LocateRegistry.getRegistry(puerto); //Localizamos el enlazador en el puerto 9999
			//URLRegistroSAutenticacion = "rmi://" + direccion + ":" + puerto + "/ServicioAutenticacion";
			//URLRegistroSMercancias = "rmi://" + direccion + ":" + puerto + "/ServicioMercancias";
			servicioAutenticacion = (ServicioAutenticacionInterface) registro.lookup(URLRegistroSAutenticacion);	
			servicioMercancias = (ServicioMercanciasInterface) registro.lookup(URLRegistroSMercancias);
			
		} catch(RemoteException e) {System.out.println(e.getMessage());
		} catch(Exception e) {System.out.println(e.getMessage());
		}
		
		System.out.println("Cliente Listo");
		
		/* Menu numero 1 */
		do{
			int valor = Menu.menu1();			
			switch (valor) {
	        case 1:
	            registrar();
	            break;
	        case 2:
	            autenticar();
	            break;
	        case 3:
	        	if (IDSesion == 0){
	        		System.out.println("Salir");
	        		System.exit(0);
			        break;
	        	} else {
	        		System.out.println("Salir");
			        System.exit(0);
			        break;
	        	}
	        default:
	        	System.out.println("Error exit code = 1");
	        	System.exit(1);
			}
		} while (!login);
		
		/* Menu numero 2 */
		while (true){
			int valor = Menu.menu2(tipo);			
			switch (valor) {
	        case 1:
	            introducirDemanda();
	            break;
	        case 2:
	            recibirOfertas();
	            break;
			case 3:
	            comprarMercancia();
	            break;
			case 4:
	            bajaSistema();
	            break;	
			case 5:
				servicioAutenticacion.salir(IDSesion); //Ponemos flag activo a false para permitir que se pueda iniciar otra sesion
				System.out.println("Salir");
		        System.exit(0);
				break;
	        default:
	        	System.out.println("Error exit code = 1");
	        	System.exit(1);
			}
		} 
	}

	
	
	/*----------------------------------*/
	/* IMPLEMENTACION METODOS ESTATICOS */
	/*----------------------------------*/
	
	/**
	 * Registramos un nuevo cliente en el sistema. proporcionamos el nombre de usuario y la clave de acceso
	 * y obtenemos el ID asignado por el servicio de autenticación
	 * Se controlan registros previos (en la misma sesion) para evitar que se pueda registrar un cliente ya registrado
	 */
	private static void registrar(){
		
		if (registrado) { //Comprobamos que el cliente no esta ya registrado en el sistema. Si lo esta mostramos sus datos de acceso
			System.out.println("USUARIO YA REGISTRADO!!!");
			System.out.println("Su sesion es: " + IDSesion);	
			try {
				System.out.println("Su nombre de usuario es: " + servicioAutenticacion.getDatosNombre(IDSesion));
				System.out.println("Su clave de acceso es: " + servicioAutenticacion.getDatosClave(IDSesion));
			} catch(RemoteException e) {System.out.println(e.getMessage());
			} catch(Exception e) {System.out.println(e.getMessage());
			}	
		} else { //Si no esta registrado solicitamos datos registro
			try{	
				String nombreUsuario= ""; //Nombre usuario
				String clave= ""; //Clave de acceso

				nombreUsuario = Menu.nombreUsuario(); //Preguntamos nombre usuario
			    clave  = Menu.claveAcceso(); //Preguntamos clave de acceso	
			    IDSesion = servicioAutenticacion.registro(nombreUsuario, clave, tipo);//Registramos el usuario y obtenemos el ID asignado por el servicio de autenticacion
				registrado = true; //El cliente se ha registrado con exito
				
				/*Mostramos por pantalla los datos de registro*/
				System.out.println("Su sesion es: " + IDSesion);		
				System.out.println("Su nombre de usuario es: " + servicioAutenticacion.getDatosNombre(IDSesion));
				System.out.println("Su clave de acceso es: " + servicioAutenticacion.getDatosClave(IDSesion));			
									
			} catch(RemoteException e) {System.out.println(e.getMessage());
			} catch(Exception e) {System.out.println(e.getMessage());
			}
		}	
	}
	
	
	
	/**
	 * Metodo encargado de validar el acceso de un cliente al sistema. Solicitamos  el nombre de usuario y la clave de acceso si el usario se ha registrado
	 * en la sesion activa (ya tenemos el IDSesion). Si el usario estaba registrado previamente pero no ha iniciado sesion, tambien solicitamos su IDSesion
	 * Una vez la sesion se ha validado se crea el servicio de call back del cliente.
	 * Al ser un ejemplo acad�mico se ha limitado el n�mero de distribuidores a 100. Se podria ampliar
	 * modificando la linea  puertoProxy = 10240 + (tmp % N); donde N seria el n�mero m�ximo de distribuidores
	 */
	private static  void autenticar() {	
		
		String nombreUsuario= "";
		String clave= "";
		boolean check = false; //Inicializamos variable de control
		int tmp = 0; //Variable usado para calcular el numero de puerto del proxy del servicio de ventas
		int puertoProxy=0; //Numero de puerto del proxy del servicio de venta
		
		if (registrado) { //Si se ha registrado en esta sesion ya conocemos el valor de IDSesion
			try{	
				try { //Verificamos si el usario tiene una sesion activa flag activo = true
					activo = servicioAutenticacion.getFlagActivo(IDSesion); 
					if (activo) {
						System.out.println ("Este usuario ya tiene una sesion activa!");
						return; //Si existe una sesion activa salimos
					}
				} catch (RemoteException e) {
					e.printStackTrace();
				}
				
				nombreUsuario = Menu.nombreUsuario(); //Preguntamos nombre usuario
			    clave  = Menu.claveAcceso(); //Preguntamos clave de acceso	
				check = servicioAutenticacion.login(IDSesion, nombreUsuario, clave, tipo); //Verificamos que la tupla nombre de usuario clave de acceso son correctas para el Id
								
				if (!check) {
					System.out.println();
					System.out.println ("Datos incorrectos, intentelo de nuevo !");	
					return; //Si los datos no son correctos salimos
				} else {
					System.out.println ("Nombre de usuario y clave de acceso correctos!");
					login = true; //login correcto
					activo = true; //Sesion activa
				}
				
				/* Creamos el servicio de callBack asociado al cliente */
				//registro = LocateRegistry.getRegistry(9999); //Obtenemos el enlazador (si estuviese en otra maquina cambia)
				registro = LocateRegistry.getRegistry(9999); //Obtenemos el enlazador (si estuviese en otra maquina cambia)
				callBackCliente = new CallBackClienteImpl();	//Creamos objeto remoto del callback
				
				///////////////////////////////////////////////////////////
				/* calculamos el numero de puerto escucha del proxy en funcion del IDSesion.  10240 + modulo 100 de IDSesion */				
				if (IDSesion<0) {
					tmp = IDSesion * -1; //No podemos seleccionar un puerto < 0
					puertoProxy = 10240 + (tmp % 100);
				} else {
					tmp = IDSesion;
					puertoProxy = 10240 + (tmp % 100);
				}
			
				Remote ServicioCallBack = UnicastRemoteObject.exportObject(callBackCliente,puertoProxy); //proxy escucha puerto = puertoProxy		
				nombreCallBack = "CallBack" + IDSesion; //nombre usado para registrar el servicio
				////////
				//System.out.println ("llego aqui!");
				//Naming.rebind("192.168.1.114" + nombreCallBack, ServicioCallBack);
				registro.rebind(nombreCallBack, ServicioCallBack); //Registramos el objeto remoto Servicio de CallBack en el enlazador
				////////
				
			} catch(RemoteException e) {System.out.println(e.getMessage());
			} catch(Exception e) {System.out.println(e.getMessage());
			}
		} else { //No se ha registrado en esta sesion y por lo tanto no sabemos IDSesion
			try{				
				IDSesion = Menu.identificador(); ////Preguntamos el ID de usuario
				
				if (IDSesion == 0 ) { //Si el metodo anterior devuelve ID = 0 es por que el formato es incorrecto y por lo tanto no debe seguir
					return;
				}
				
				try { //Verificamos si el usario tiene una sesion activa flag activo = true
					activo = servicioAutenticacion.getFlagActivo(IDSesion); 
					if (activo) {
						System.out.println ("Este usuario ya tiene una sesion activa!");
						return; //Si existe una sesion activa salimos
					}
				} catch (RemoteException e) {
					e.printStackTrace();
				}
				
				nombreUsuario = Menu.nombreUsuario(); //Preguntamos nombre usuario
				clave  = Menu.claveAcceso(); //Preguntamos clave de acceso
				check = servicioAutenticacion.login(IDSesion, nombreUsuario, clave, tipo); //Verificamos que la tupla nombre de usuario clave de acceso son correctas para el Id
							
				if (!check) { //Si no es correcto se informa del error
					System.out.println();
					System.out.println ("Datos incorrectos, intentelo de nuevo !");	
					return; //Si los datos no son correctos salimos
				} else {
					System.out.println ("Nombre de usuario y clave de acceso correctos!");
					login = true; //login correcto
					activo = true; //Sesion activa
				}
				
				/* Creamos el servicio de callBack asociado al cliente */
				registro = LocateRegistry.getRegistry(9999); //Obtenemos el enlazador (si estuviese en otra maquina cambia)
				//registro = LocateRegistry.getRegistry(ip,9999); //Obtenemos el enlazador (si estuviese en otra maquina cambia)
				callBackCliente = new CallBackClienteImpl();	//Creamos objeto remoto del callback
				
				if (IDSesion<0) {
					tmp = IDSesion * -1; //No podemos seleccionar un puerto < 0
					puertoProxy = 10240 + (tmp % 100);
				} else {
					tmp = IDSesion;
					puertoProxy = 10240 + (tmp % 100);
				}
			
				Remote ServicioCallBack = UnicastRemoteObject.exportObject(callBackCliente,puertoProxy); //proxy escucha puerto = puertoProxy		
				nombreCallBack = "CallBack" + IDSesion; //nombre usado para registrar el servicio
				registro.rebind(nombreCallBack, ServicioCallBack); //Registramos el objeto remoto Servicio de CallBack en el enlazador
			} catch(RemoteException e) {System.out.println(e.getMessage());
			} catch(Exception e) {System.out.println(e.getMessage());
			}
		}
	}
	
	
	/**
	 * Metodo encargado de permitir al cliente registrar una nueva demanda de mercancia.
	 * Se muestra por consola las opciones disponibles de la clase enumerada Mercancia.
	 * @throws RemoteException al usar el Servicio de Mercancias para añadir la demanda.
	 *
	 */
	private static void introducirDemanda() throws RemoteException{
		
		String tipoMercancia = Menu.introducirTipo();
		servicioMercancias.addDemanda(IDSesion, tipoMercancia); //Añadimos la demanda en la BBDD del Servicio de Mercancias	
	}
	
	
	/**
	 * Metodo encargado de mostrar en la consola del cliente todas las ofertas registradas en el Servicio de Mercancias.
	 * Obtenemos todas las ofertas registradas y luego se pasan al método imprimir() que las imorime or consila.
	 * Se controla que la lista de ofertas no esta vacia..
	 * @throws RemoteException al usar el Servicio de Mercancias para obtener las ofertas registradas
	 */
	private static void recibirOfertas()throws RemoteException {
		
		ArrayList<String> listado = new ArrayList<String>();
		listado = servicioMercancias.listarOfertasToArray(); //Array con la informacion de las ofertas		
				
		if (listado.isEmpty()){ //Si la lista esta vacia no hay ofertas registradas
			System.out.println("\nNo hay ofertas registradas"); //Informamos que no hay ofertas
			return;
		} else {
			System.out.println("Listado ofertas"); //Cabecera del listado
		}
		
		imprimir(listado); //Imprimimos el listado por la consola			
	}
	
	/**
	 * Metodo encargado de gestionar la compra de una oferta.
	 * Obtenemos una lista actualizada de las ofertas y luego solicitamos los datos de la oferta
	 * Verificancando que los datos son correctos (Formatos, IDDistribuidor, Indice de la oferta) 
	 * @throws RemoteException al usar el Servicio de Mercancias, Servicio de Ventas y el metodo recibirOfertas()
	 */
	private static void comprarMercancia() throws RemoteException{
				
		recibirOfertas(); //Actualizamos la variable ofertasDataBase y la mostramos por pantalla llamando al metodo recibirOfertas()
			
		ArrayList<String> listadoOfertas = servicioMercancias.listarOfertasToArray();
		if (listadoOfertas.isEmpty()){ //Verificamos si existe alguna oferta registrada 
			return; //Si no hay ofertas registradas volvemos al menu
		} 
		
		int identificador = Menu.identificador();; //Identificador del distribuidor
		
		boolean checkID = servicioMercancias.checkIdentificador(identificador);
		if (!checkID){
			System.out.println ("\nIdentificador del distribuidor incorrecto!");
			return;
		}
		
		
		boolean checkOnline = servicioAutenticacion.getFlagActivo(identificador);
		if (!checkOnline){
			System.out.println ("\nDistribuidor offline, no se puede realizar la compra!");
			return;
		}
		
		    
		int nOferta = Menu.numeroOferta(); //Numero de oferta a comprar		    
				
		/* Obtenemos el enlazador y localizamos el servicio de venta remoto */	
		try{
			Registry registro = LocateRegistry.getRegistry(9999);
			String nombre = "ServicioVenta" + identificador; //Obtenemos el identificar del Servicio de Venta 
			ServicioVenta = (ServicioVentaInterface) registro.lookup(nombre);	
		} catch(RemoteException e) {System.out.println(e.getMessage());
		} catch(Exception e) {System.out.println(e.getMessage());
		}
				
		
		boolean controlVenta = ServicioVenta.registarVenta(identificador, nOferta-1); //Se controla que la venta se puede realizar
		if (!controlVenta) {
			System.out.println ("ERROR. La operacion no se puede completar!");
			return; //Si hay algun error salimos
		}
		
		/* Si la venta se completa eliminamos la demanda y la oferta de las BBDD correspondientes */
		servicioMercancias.quitarDemandas(identificador, IDSesion, nOferta-1);
		servicioMercancias.quitarOfertas(identificador, nOferta-1); 	
		System.out.println ("\nCompra completada!");
	}
	
	/**
	 * M�todo encargado de gestionar la baja de un cliente del sistema
	 * La operaci�n no se puede deshacer por lo que solicitamos  confirmaci�n antes de procesarla
	 * Una vez procesada la baja el programa termina. Tambien se eliminan todas las demandas asociadas.
	 */
	private static void bajaSistema(){
			
		boolean control = false; //Variable que controla si el borrado del usuario en el servicio de autenticacion ha sido correcto,
			
		try{
			System.out.println ("Esta operacion no se puede deshacer, esta seguro? (Si/No).");
			String opcion = "";
			@SuppressWarnings("resource")
			Scanner escaner = new Scanner (System.in); //Creacion de un objeto Scanner
			opcion = escaner.nextLine ().trim(); //eliminamos espacios en blanco
			
			if (opcion.equalsIgnoreCase("Si") ||opcion.equalsIgnoreCase("S")) {
				control = servicioAutenticacion.bajaSistema(IDSesion); //Damos de baja en el servicio de auntenticacion
				if (control) {
					servicioMercancias.bajaSistema(IDSesion,tipo,control); //damos de baja sus ofertas si control == true
				}
					
				try {
					registro.unbind(nombreCallBack); //desregistramos el objeto remoto
					} catch(RemoteException e) {System.out.println(e.getMessage());
					} catch(Exception e) {System.out.println(e.getMessage());
					}
					
				try {
					UnicastRemoteObject.unexportObject(callBackCliente, true); //eliminamos el objeto remoto
					} catch (NoSuchObjectException e) {System.out.println(e.getMessage());
					}
					
				System.out.println("Cliente Apagado");
				System.exit(0); //Fin del programa (exit code 0)
			} else {
				System.out.println ("Operacion cancelada!");
			}
		} catch(RemoteException e) {System.out.println(e.getMessage());
		} catch(Exception e) {System.out.println(e.getMessage());
		}
	}


	/**
	* Metodo encargado de imprimir con formato la lista de ofertas que se pasa como parametro
	* @param lista. La lista de tipo string con lo datos a imprimir
	*/
	private static void imprimir(ArrayList<String> lista) {
		ArrayList<String> listado = lista; //Lista con las ofertas del distribuidor
		int size = listado.size(); //Variable para controlar el numero de iteraciones
		int numeroOferta = 1; //Numero de oferta
					
		/* Imprimos por la consola del cliente la informacion del listado de ofertas. Vamos controlando por la posicion de la lista que 
		 * infomacion se imprime para mantener el formato. La lista se ha creado con esta estructura Identificador[0] Tipo[1] Precio[2]
		 * Peso[3] Identificador[4] de esta forma podemos usar el operador modulo para elegir que valor imprimir según iteramos la lista */
		for (int i=0; i < size; i++){						
			if (i != 0 && i % 4 == 0){
				System.out.println(""); //Si no es la primera linea de la lista pero es una cabezera de linea saltamos a la siguiente linea
					
				boolean controlId = listado.get(i).equals(listado.get(i-4)); //Cada inicio de linea verificamos si el IDSesion cambia respecto al anterior. Si es distinto reseteamos a 1 el contador de numero de oferta
					
				if (!controlId) {
					System.out.println(""); //Insertamos linea en blanco
					numeroOferta = 1;
				}
			}
				
			if (i % 4 == 0){ //si es una primera columna de la fila imprimimos numero de oferta e identificador 
				System.out.print(String.format("%8s %3s %10s %13s", "Oferta:", numeroOferta,  "  Identificador: ", listado.get(i) + "  "));
			}
				
			if (i % 4 == 1){ //Si es la segunda columna imprimimos el tipo de la oferta
				System.out.print(String.format("%6s %10s", " Tipo: ", listado.get(i) + "  "));
			}
			
			if (i % 4 == 2){ //Si es la tercera columna imprimimos el precio
				System.out.print(String.format("%9s %18s", " Precio: ", listado.get(i) + " Euros  "));
			}
					
			if (i % 4 == 3){ //Si es la cuarta columna imprimimos el peso
				System.out.print(String.format("%8s %14s", " Peso: ", listado.get(i) + " Kilos "));
			}
				
			if (i % 4 == 0){
				numeroOferta++; //cada 4 iteraciones incrementamos el numero de la oferta
			}
		}
		
		System.out.println("\n");
	}
}
