package uned.sidi.comun;

/**
 * Clase Mercancia. Representa el tipo de mercancia.
 * Al ser una lista cerrada se ha decidido crear un tipo enumerado.
 * @author (Jose Javier Culebras Perez)
 * @author D.N.I. 02641584
 * @author TFO. 675972087
 * @author Centro asociado. Las Tablas. 
 * @version	0.1  Mayo 2018
 *  
 */

public enum Mercancia {

	    TOMATES,
	    LIMONES,
	    NARANJAS,
	    FRESAS,
	    PLATANOS,
	    MELONES,
	    SANDIAS;
}
