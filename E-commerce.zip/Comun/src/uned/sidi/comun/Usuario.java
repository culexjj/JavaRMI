package uned.sidi.comun;

import java.io.Serializable;


public class Usuario implements Serializable {
	
	/*--------------------------*/
	/* DECLARACION DE VARIABLES */
	/*--------------------------*/
	
	private static final long serialVersionUID = 1288229977112266553L;
	private String nombre; //nombre del usuario
	private String clave; //Clave de acceso
	private int	tipo; //Tipo de usuario Cliente o Distribuidor
	private boolean activo; //Flag para indicar si el usuario tiene una sesion activa (ha iniciado sesion)
	
	
	/*--------------------------*/
	/*       CONSTRUCTORES      */
	/*--------------------------*/
	
	public Usuario (String nombre, String clave, int tipo){
		this.nombre = nombre;
		this.clave = clave;	
		this.tipo = tipo;
		this.activo = false; //Por defecto no esta logeado
	}

	
	/*--------------------------*/
	/*    METODOS   PUBLICOS    */
	/*--------------------------*/
	
	/**
	 * Obtenemos el nombre de un usuario
	 * @return nombre
	 */
	public String getNombre(){
		return nombre;
	}
	
	
	/**
	 * Obtenemos la clave de acceso
	 * @return clave
	 */
	public String getClave(){
		return clave;
	}
	
	
	/**
	 * Obtenemos el tipo de un usario 0-Distribuidor 1-Cliente
	 * @return tipo de usuario
	 */
	public int getTipo(){
		return tipo;
	}
	
	
	/**
	 * Obtenemos el flag que indica si un usario ha inicido sesion
	 * @return el flag activo
	 */
	public boolean getFlagActivo(){
		return activo;
	}
	
	
	/**
	 * Establecemos el valor del atributo activo a True o False
	 * @param activo
	 */
	public void setFlagActivo(boolean activo){
		this.activo = activo;
	}
}
