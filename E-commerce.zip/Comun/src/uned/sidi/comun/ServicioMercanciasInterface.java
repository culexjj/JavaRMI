package uned.sidi.comun;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.List;
//import java.util.Map;



public interface ServicioMercanciasInterface extends Remote{
	
	public void addOferta(Integer iDSesion, String tipoMercancia, double precio, int kilos) throws RemoteException; //Añade una oferta de un distribuidor
	public void addDemanda(Integer iDSesion, String tipoMercancia) throws RemoteException; //Añade una demanda de un cliente
	public void quitarOfertas(int iDSesion,int numero) throws RemoteException; //Eliminar una oferta de un distribuidor de la BBDD ofertas
	public void quitarDemandas(int iDDistribuidor,int iDCliente, int numero) throws RemoteException;//Eliminar una demanda de un cliente de la BBDD demandas
	public List<Oferta> getOfertas(int iDSesion) throws RemoteException; //Obtener todas las ofertas de un distribuidor cuoy ID se pasa como argumento
	public ArrayList<String> listarOfertasToArray() throws RemoteException; //Listado de todas las ofertas como una lista
	public ArrayList<String> listarOfertasToArray(int id) throws RemoteException; //Listado de todas las ofertas como una lista de un distribuidor 
	public ArrayList<Integer> buscarDemanda (String tipoMercancia) throws RemoteException; //Buscar demandas entre los clientes que sean igual al tipo de mercancia pasado
	public boolean checkIdentificador (int iDSesion) throws RemoteException; //Verificamos si existe el id
	public void bajaSistema(int iDSesion, int tipo, boolean control) throws RemoteException; // Eliminamos de las BBDD las demandas/ofertas de un usuario
	
}
