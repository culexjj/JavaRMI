package
uned.sidi.regulador;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Map.Entry;

import uned.sidi.comun.Demanda;
import uned.sidi.comun.Mercancia;
import uned.sidi.comun.Oferta;
import uned.sidi.comun.ServicioMercanciasInterface;



public class ServicioMercanciasImpl implements ServicioMercanciasInterface{
	
	/*--------------------------*/
	/* DECLARACION DE VARIABLES */
	/*--------------------------*/
	
	private Map<Integer,List<Oferta>> ofertasDataBase; //Map que registra las ofertas de los distribudiores
	private Map<Integer,List<Demanda>> demandasDataBase; //Map que registra las demandas de los clientes

	
	/*--------------------------*/
	/*       CONSTRUCTORES      */
	/*--------------------------*/
	
	protected ServicioMercanciasImpl() throws RemoteException {
		super();
		ofertasDataBase = new HashMap<Integer,List<Oferta>>();
		demandasDataBase = new HashMap<Integer,List<Demanda>>();
	}
	
	
	/*--------------------------*/
	/*    METODOS   INTERFAZ    */
	/*--------------------------*/

	/**
	 * Método encargado de registrar las ofertas de los distribuidores
	 * Se comprueba que la lista asociada al ID del distribuidore existe y si no es así se crea una nueva
	 * Recibe como parámetros el ID del distribuidor y los datos de la oferta a registrar
	 * @param iDSesion. el identificador del usuario
	 * @param tipoMercancia. el tipo de mercancia 
	 * @param precio. el precio de la oferta
	 * @param kilos. el peso de la oferta
	 * @throws RemoteException
	 */
	@Override
	public synchronized void addOferta(Integer iDSesion, String tipoMercancia, double precio, int kilos) throws RemoteException {
	
		Mercancia tipo = Mercancia.valueOf(tipoMercancia); //Valor de tipo de mercancia equivalente al string que se pasa como parametro
		List<Oferta> listado = ofertasDataBase.get(iDSesion); //listado de ofertas del distribuidor
		
		if (listado == null){ //Si no existe se crea
			listado = new LinkedList<Oferta>();
			ofertasDataBase.put(iDSesion, listado);
		}

		Oferta oferta = new Oferta(tipo, precio, kilos); //Creamos un objeto oferta
		listado.add(oferta); //Añadimos la oferta			
	}
	
	
	/**
	 * Método encargado de registrar las demandas de los clientes
	 * Se comprueba que la lista asociada al ID del cliente existe y si no es así se crea una nueva
	 * Recibe como parámetros el ID del distribuidor y la demanda a registrar
	 * @param iDSesion. el identificador del usuario
	 * @param tipoMercancia. el tipo de mercancia 
	 * @throws RemoteException
	 */
	@Override
	public synchronized void addDemanda(Integer iDSesion, String tipoMercancia) throws RemoteException{
		    
		Mercancia tipo = Mercancia.valueOf(tipoMercancia); //Valor de tipo de mercancia equivalente al string que se pasa como parametro
		
		List<Demanda> listado = demandasDataBase.get(iDSesion);  //listado de demandas del cliente
		
		if (listado == null){ //Si no existe se crea
			listado = new LinkedList<Demanda>();
			demandasDataBase.put(iDSesion, listado);
		}
		
		Demanda demanda = new Demanda(tipo); //Creamos un objeto demanda
		listado.add(demanda); //Añadimos la demanda	
	}
	
	
	
	
	
	/**
	 * Método encargado de listar todas las ofertas registradas 
	 * devuelve un array con las ofertas en un formto que permite imprimirlas
	 * @return array. la lista de oferttas
	 * @throws RemoteException
	 */
	public synchronized ArrayList<String> listarOfertasToArray() throws RemoteException{
		
		Mercancia tipoMercancia = Mercancia.TOMATES; //Es necesario inicilizar la variable		
		int kilos = 0;	//Peso de la oferta			
		double precio=0.00;	//Precio de la oferta
		
		ArrayList<String> array = new ArrayList<String>(); //Array con la informacion que devolvemos
				
		try{
			Iterator<Entry<Integer, List<Oferta>>> iterador = ofertasDataBase.entrySet().iterator(); //Obtenemos un objeto iterador
			while (iterador.hasNext()) {
				Map.Entry<Integer, List<Oferta>> listado = (Map.Entry<Integer, List<Oferta>>) iterador.next();
					
				int key = listado.getKey(); //Obtenemos el valor del ID del distribuidor
					
				List<Oferta> lista = ofertasDataBase.get(key); // Obtenemos la lista de ofertas asociada al ID e iteramos sobre ella
				Iterator<Oferta> iterador2 = lista.iterator();
				while (iterador2.hasNext()){
					Oferta oferta = (Oferta) iterador2.next();
					tipoMercancia = oferta.getTipo();
					precio = oferta.getPrecio();
					kilos = oferta.getKilos();
						
					array.add(String.valueOf(key));
					array.add(String.valueOf(tipoMercancia));
					array.add(String.valueOf(precio));
					array.add(String.valueOf(kilos));
				}	
			}
		} catch(NoSuchElementException e) {System.out.println(e.getMessage());
		} catch(NullPointerException e) {System.out.println(e.getMessage());
		} catch(Exception e) {System.out.println(e.getMessage());
		}
		
		return array; //Devolvemos la lista de ofertas
	}		
			
	
	/**
	 * Método encargado de listar todas las ofertas registradas de un distribuidor
	 * devuelve un array con las ofertas en un formto que permite imprimirlas
	 * @param iDSesion. el identificador del usuario
	 * @return listado. la lista de ofertas del identificador que se pasa como parametro
	 * @throws RemoteException
	 */
	public synchronized ArrayList<String> listarOfertasToArray(int iDSesion) throws RemoteException{
		
		Mercancia tipoMercancia = Mercancia.TOMATES; //Es necesario inicilizar la variable		
		int kilos = 0;	//Peso de la oferta			
		double precio=0.00;	//Precio de la oferta
		
		ArrayList<String> listado = new ArrayList<String>(); //Array con la informacion que devolvemos
					
		try{
			List<Oferta> lista = ofertasDataBase.get(iDSesion);  // Obtenemos la lista de ofertas asociada al ID e iteramos sobre ella
			Iterator<Oferta> iterador2 = lista.iterator();
			while (iterador2.hasNext()){
				Oferta oferta = (Oferta) iterador2.next();
				tipoMercancia = oferta.getTipo();
				precio = oferta.getPrecio();
				kilos = oferta.getKilos();
						
				listado.add(String.valueOf(iDSesion));
				listado.add(String.valueOf(tipoMercancia));
				listado.add(String.valueOf(precio));
				listado.add(String.valueOf(kilos));	
			}	
		} catch(NoSuchElementException e) {System.out.println("");
		} catch(NullPointerException e) {System.out.println("");
		} catch(Exception e) {System.out.println("");
		}
			
		return listado;
	}		

	
	
	
	/**
	 * Método encargado de devolver la lista de ofertas de un distribuidor pasado como parámetro
	 * @param iDSesion. el identificador del usuario
	 * @return lista. La lista de ofertas
	 */
	public synchronized List<Oferta> getOfertas(int iDSesion){
		List<Oferta> lista = ofertasDataBase.get(iDSesion);
		return lista; //La lista de ofertas
	}
	
	
	/**
	 * Método encargado de borrar una oferta determinada de la lista de ofertas de un distribuidor
	 * Recibe como parámetros de entrada el ID del distribuidor y el número de oferta a borrar
	 * Si el ID no existe lanzamos una excepción en tiempo de ejecución informando que el ID no existe
	 * @param iDSesion. el identificador del usuario
	 * @param numero. el numero de la oferta a suprimir
	 * @throws RemoteException
	 */
	
	public synchronized void quitarOfertas(int iDSesion, int numero) throws RemoteException{
		
		if (!ofertasDataBase.containsKey(iDSesion)){ //Verificamos que el ID existe
			throw new RuntimeException("DISTRIBUIDOR NO REGISTRADO!!!");
		}
		
		List<Oferta> lista = ofertasDataBase.get(iDSesion); //Obtenemos la lista de ofertas
		lista.remove(numero); //Borramos la oferta		
	}
	
	
	/**
	 * Metodo encargado de quitar una Demanda de la lista de demandas de un cliente cuando realiza una compra
	 * Se busca si existe una demanda con el mismo tipo de mercancia que la oferta que se compra
	 * @param int idDistribuidor. Identificador del distribuidor
	 * @param int idCliente. Identificador del cliente
	 * @param int numero. numero de la oferta que se compra
	 * @throws RemoteException
	 */
	
	public synchronized void quitarDemandas(int iDDistribuidor,int iDCliente, int numero) throws RemoteException{
	
		List<Oferta> listadoOfertas = ofertasDataBase.get(iDDistribuidor); 	//obtenemos la lista de ofertas del distribuidor al que vamos a comprar
		Oferta oferta = listadoOfertas.get(numero);
		Mercancia tipo = oferta.getTipo(); //Tipo de la oferta a buscar
		
		List<Demanda> listadoDemandas = demandasDataBase.get(iDCliente); //obtenemos la lista de demandas del cliente que compra
		int indice = 0; //indice de la demanda a eliminar
		
		try{
			Iterator<Demanda> iterador2 = listadoDemandas.iterator(); //Vamos iterando por la lista de demandas
			while (iterador2.hasNext()){
				Demanda demanda = (Demanda) iterador2.next();
					
				Mercancia tipoMercancia = demanda.getTipo();
					
				if (tipoMercancia == tipo) { //Cuando encontramos la primera demanda cuyo tipo es igual al tipo de la oferta que se compra
					listadoDemandas.remove(indice); //La eliminamos
					break; //Y salimos
				}
					
				indice++; //Vamos actualizando el indice de la lista de demandas	 
			}
		} catch(NoSuchElementException e) {System.out.println(e.getMessage());
		} catch(NullPointerException e) {System.out.println(e.getMessage());
		} catch(Exception e) {System.out.println(e.getMessage());
		}	
	}
	
	
	/**
	 * Método encargado de eliminar las ofertas / demandas de un usuario en la BBDD de demandas
	 * @param iDSesion. el identificador del usuario
	 * @param tipo.El  tipo de usuario (0.distribuidor 1.cliente)
	 * @param control. 
	 * @throws RemoteException
	 */
	
	@Override
	public synchronized void bajaSistema(int iDSesion, int tipo, boolean control) throws RemoteException {
		//si la variable de control vale true entonces el id pasado como parametro es correcto.
		//en ese caso si la base de ofertas o demandas no contiene el ID es porque no se ha registrado 
		//ninguna oferta y demanda por lo que no hay nada que borrar.
		
		if (control) {		//A REVISAR	
			if (tipo==0){//controlamos si es un cliente o un distribudior y borramos sus datos de la BBDD correspondiente
				//Verificamos que el ID existe
				if (!ofertasDataBase.containsKey(iDSesion)){
					return; 
					//throw new RuntimeException("USUARIO NO REGISTRADO!!!");
				} else {
					ofertasDataBase.remove(iDSesion);
				}
				
			} else {
				//Verificamos que el ID existe
				if (!demandasDataBase.containsKey(iDSesion)){
					return;
					//throw new RuntimeException("USUARIO NO REGISTRADO!!!");
				} else {
					demandasDataBase.remove(iDSesion);
				}
			}	
		}
	}
		
		
		
	/**
	 * Metodo encargado de buscar en la lista de demandas de los clientes cuales coinciden con el tipo de la oferta que se
	 * esta realizando. La lista contiene los identificadores de los clientes a los cuales se les avisara mediante el callback
	 * que se acaba de registrar una oferta de un tipo de mercancia igual a alguna de sus demandas 
	 * @param tipoMercancia. el tipo de mercancia a buscar
	 * @return listado. el listado de los clientes que han realizado un demanda = tipoMercancia
	 * @throws RemoteException	
	 */
	@Override
	public synchronized ArrayList<Integer> buscarDemanda(String tipoMercancia) throws RemoteException {
		
		ArrayList<Integer> listado = new ArrayList<Integer>(); //Array con la informacion que devolvemos
		Mercancia valorBuscado = Mercancia.valueOf(tipoMercancia); //Valor a buscar
		Mercancia tipoMercancia2 = Mercancia.TOMATES; //Es necesario inicializar la variable
		
		Iterator<Entry<Integer, List<Demanda>>> iterador = demandasDataBase.entrySet().iterator(); //obtemos el objeto iterador sobre demandasDataBase
		while (iterador.hasNext()) {
			Map.Entry<Integer, List<Demanda>> ofertas = (Map.Entry<Integer, List<Demanda>>) iterador.next();	
			int key = ofertas.getKey(); //Obtenemos el Identificador del cliente 							
				
			List<Demanda> lista = demandasDataBase.get(key); //Obtenemos la lista de demandas del cliente e iteramos sobre ella para revisar todas las demandas de ese cliente
			Iterator<Demanda> iterador2 = lista.iterator();
			while (iterador2.hasNext()){
					
				Demanda demanda = (Demanda) iterador2.next();						
				tipoMercancia2 = demanda.getTipo();	//Tipo de la demanda
										
				/* Si encontramos una demanda que coincide con el tipo de la oferta que se esta registrando */
	
				if (tipoMercancia2.equals(valorBuscado)){
					listado.add(key); //A�adimos el identificador del cliente
					break; //Con encontrar una coincidencia es suficiente. salimos del bucle interno
				}
			}
		}			

		return listado;
	}

	
	/**
	 * Metodo que verifica que el identificador del usuario pasado como parametro existe en la
	 * BBDD de ofertas
	 * @param iDSesion. el identificador del usuario
	 * @return el resultado de la operación
	 * @throws RemoteException	
	 */
	@Override
	public synchronized boolean checkIdentificador(int iDSesion) throws RemoteException {
		if (ofertasDataBase.containsKey(iDSesion)){
			return true;
		} else {
			return false;
		}
	}	
	
	
	
	/*--------------------------*/
	/*    METODOS   PUBLICOS    */
	/*--------------------------*/

	/**
	 * Método encargado de listar todas las ofertas registradas
	 * Vamos iterando por mostrando todas las ofertas de cada distribuidor
	 * @throws RemoteException
	 */
	public synchronized void listarOfertas() { //throws RemoteException{
		
		Mercancia tipoMercancia = Mercancia.TOMATES; //Es necesario inicilizar la variable		
		int kilos = 0;	//Peso de la oferta			
		double precio=0.00;	//Precio de la oferta
		
		System.out.println("\nListado ofertas");
					
		try{
			Iterator<Entry<Integer, List<Oferta>>> iterador = ofertasDataBase.entrySet().iterator(); //Obtenemos un objeto iterador
			while (iterador.hasNext()) {
				Map.Entry<Integer, List<Oferta>> listado = (Map.Entry<Integer, List<Oferta>>) iterador.next();
					
				int key = listado.getKey(); //Obtenemos el valor del ID del distribuidor
					
				System.out.println("Identificador: " + key );
					
				List<Oferta> lista = ofertasDataBase.get(key); //Obtenemos la lista de ofertas asociada al ID e iteramos sobre ella
				Iterator<Oferta> iterador2 = lista.iterator();
				while (iterador2.hasNext()){
					Oferta oferta = (Oferta) iterador2.next();
						
					tipoMercancia = oferta.getTipo();
					precio = oferta.getPrecio();
					kilos = oferta.getKilos();
						
					System.out.println(String.format("%6s %8s %8s %9s %14s %5s %2s" , " Tipo :", tipoMercancia,  " precio :", precio, "Euros  Kilos :",  kilos,  "Kg" ));
				}	
			}
		} catch(NoSuchElementException e) {System.out.println(e.getMessage());
		} catch(NullPointerException e) {System.out.println(e.getMessage());
		} catch(Exception e) {System.out.println(e.getMessage());
		}	
	}
	
	
	/**
	 * Método encargado de listar todas las demandas registradas
	 * Vamos iterando por mostrando todas las demandas de cada cliente
	 * @throws RemoteException
	 */	
	public synchronized void listarDemandas() { //throws RemoteException{
		
		Mercancia tipoMercancia = Mercancia.TOMATES; //Es necesario inicializar la variable		
		
		System.out.println("\nListado demandas");
					
		try{
			Iterator<Entry<Integer, List<Demanda>>> iterador = demandasDataBase.entrySet().iterator();  //Obtenemos un objeto iterador
			while (iterador.hasNext()) {
				Map.Entry<Integer, List<Demanda>> listado = (Map.Entry<Integer, List<Demanda>>) iterador.next();
				int key = listado.getKey(); //Obtenemos el valor del ID del distribuidor
					
				System.out.println("Identificador: " + key );
					
				List<Demanda> lista = demandasDataBase.get(key); // Obtenemos la lista de demandas asociada al ID e iteramos sobre ella
				Iterator<Demanda> iterador2 = lista.iterator();
				while (iterador2.hasNext()){
					Demanda demanda = (Demanda) iterador2.next();
					tipoMercancia = demanda.getTipo();
					System.out.println(String.format("%6s %8s" , " Tipo :", tipoMercancia));
				}	
			}
		} catch(NoSuchElementException e) {System.out.println(e.getMessage());
		} catch(NullPointerException e) {System.out.println(e.getMessage());
		} catch(Exception e) {System.out.println(e.getMessage());
		}
	}
	
	
}

