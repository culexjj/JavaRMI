package uned.sidi.regulador;

import java.rmi.Remote;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;

import uned.sidi.comun.Menu;
import uned.sidi.comun.ServicioAutenticacionInterface;
import uned.sidi.comun.Utils;



public class Regulador {
	
	private static int puerto = 9999; //N�mero de puerto donde vamos a crear el enlazador
	private static Registry registro; //Objeto registry
	private static String direccion = "localhost"; //host
	
	
	public static void main(String[] args) throws Exception {
		
		String URLRegistroSAutenticacion; //Url completa servicio autenticaci�n
		String URLRegistroSMercancias; //Url completa servicio mercancias
		
		Utils.setCodeBase(ServicioAutenticacionInterface.class); //java.rmi.server.codebase
		
		
		LocateRegistry.createRegistry(puerto); //Creamos el enlazador en el puerto 9999
		registro = LocateRegistry.getRegistry(puerto); //Obtenemos el enlazador
		
		ServicioAutenticacionImpl SAutenticacion = new ServicioAutenticacionImpl();	//Creamos objeto remoto del Servicio Autenticacion		
		Remote SAutenticacionRemote = UnicastRemoteObject.exportObject(SAutenticacion, 8899); //proxy escucha puerto 8899
		URLRegistroSAutenticacion = "rmi://" + direccion + ":" + puerto + "/ServicioAutenticacion";
		registro.rebind(URLRegistroSAutenticacion, SAutenticacionRemote); //Registramos el objeto remoto Servicio de Autenticacion en el enlazador
		System.out.println("Servicio Autenticacion Listo");
		
		ServicioMercanciasImpl SMercancias = new ServicioMercanciasImpl(); //Creamos objeto remoto del Servicio Mercancias		
		Remote SMercanciasRemote = UnicastRemoteObject.exportObject(SMercancias, 8899); //proxy escucha puerto 8899
		URLRegistroSMercancias = "rmi://" + direccion + ":" + puerto + "/ServicioMercancias";	
		registro.rebind(URLRegistroSMercancias, SMercanciasRemote); //Registramos el objeto remoto Servicio de Mercancias en el enlazador		
		System.out.println("Servicio Mercancias Listo");
		
		System.out.println("Regulador listo");
		
		do{
			int valor = Menu.menu3();			
			switch (valor) {
	        case 1:
	        	SMercancias.listarOfertas();
	            break;
	        case 2:
	        	SMercancias.listarDemandas();
	            break;
			case 3:
	            SAutenticacion.listarUsuarios(1); //Se pasa como parametro el tipo de usario ya que distribuidores y clientes comparten la misma BBDD Servicio Autenticacion
	            break;
			case 4:
	            SAutenticacion.listarUsuarios(0); //Se pasa como parametro el tipo de usario ya que distribuidores y clientes comparten la misma BBDD Servicio Autenticacion
	            break;
			case 5: //Salimos
				registro.unbind(URLRegistroSAutenticacion); //Desregistramos el objeto remoto y eliminamos el objeto remoto Servicio autenticacion
		        UnicastRemoteObject.unexportObject(SAutenticacion, true);	
		        registro.unbind(URLRegistroSMercancias);	//Desregistramos el objeto remoto y eliminamos el objeto remoto Servicio mercancias
				UnicastRemoteObject.unexportObject(SMercancias, true);	
				System.out.println("Regulador Apagado");
		        System.exit(0);
		        break;
	        default:
	        	System.out.println("Error exit code = 1");
	        	System.exit(1);
			}
		} while (true);
	}
}
 