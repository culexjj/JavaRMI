package uned.sidi.distribuidor;

import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;

import uned.sidi.comun.Mercancia;


import uned.sidi.comun.Oferta;
import uned.sidi.comun.ServicioMercanciasInterface;
import uned.sidi.comun.ServicioVentaInterface;

public class ServicioVentaImpl implements ServicioVentaInterface {
	
	/*--------------------------*/
	/* DECLARACION DE VARIABLES */
	/*--------------------------*/
	
	private Map<Integer,List<Oferta>> ventasDataBase; ////Map que registra las ventas de los distribuidores
	private  ServicioMercanciasInterface servicioMercancias; //Objeto remoto Servicio de mercancias
	private String URLRegistroSMercancias = "";
	private String direccion = "localhost"; //host
	private int puerto = 9999; //Número de puerto de escucha del enlazador
	
	/*--------------------------*/
	/*       CONSTRUCTORES      */
	/*--------------------------*/
	
	protected ServicioVentaImpl() throws RemoteException {
		super();
		ventasDataBase = new HashMap<Integer,List<Oferta>>();
		try{
			Registry registro = LocateRegistry.getRegistry(puerto); //Localizamos el enlazador en el puerto 9999
			URLRegistroSMercancias = "rmi://" + direccion + ":" + puerto + "/ServicioMercancias";
			servicioMercancias = (ServicioMercanciasInterface) registro.lookup(URLRegistroSMercancias);
		} catch(RemoteException e) {System.out.println(e.getMessage());
		} catch(Exception e) {System.out.println(e.getMessage());
		}
		
	}
	
	/*--------------------------*/
	/*    METODOS   PUBLICOS    */
	/*--------------------------*/

	/**
	 * Método encargado de registrar una venta de un distribuidor. Recibe como parámetros el ID del distribuidor
	 * y el numero de oferta de la venta realizada. Controlamos que la lista asociada al distrubuidor existe y si
	 * no es así se crea. Tambien se controla que el numero de oferta es correcto. Si no es asi el metodo devuelve
	 * false indicando que la venta no se ha realizado de forma correcta
	 * @param iDSesion. El identificador del distribuidor
	 * @param numero. el numero de oferta a registrar
	 * @return el resultado de la operación 
	 * @throws RemoteException
	 */
	public synchronized boolean registarVenta(Integer iDSesion, int numero) throws RemoteException {
		
		Oferta oferta; //Oferta a registrar como venta
		List<Oferta> listadoOfertas = servicioMercancias.getOfertas(iDSesion);//Obtenemos las ofertas del distribuidor
		
		try{ 
			oferta = listadoOfertas.get(numero); //Control para evitar la excepcion si intentamos acceder a un indice que no existe,
		   } catch (IndexOutOfBoundsException e){
			   return false; //El numero de oferta no existe. No se puede commpletar la venta
		   }
		
		List<Oferta> listadoVentas = ventasDataBase.get(iDSesion); //Obtenemos el listado de ventas del distribuidor
					
			if (listadoVentas == null){
				listadoVentas = new LinkedList<Oferta>(); //Si no existe, se crea
				ventasDataBase.put(iDSesion, listadoVentas);
			}
			
			listadoVentas.add(oferta); //añadimos la venta a la BBDD de ventas del distribuidor
			return true; //La venta se ha realizado correctamente		
	}

	/**
	* Devolvemos un lista tipo string con todas las ventas del distribuidor cuyo identificador se
	* pasa como parametro
	* @param iDSesion. El identificador del distribuidor
	* @return listado. Lista con la ventas
	* @throws RemoteException
	*/
	public synchronized ArrayList<String> listarVentasToArray(int iDSesion) throws RemoteException{
			
		Mercancia tipoMercancia = Mercancia.TOMATES; //Es necesario inicilizar la variable		
		int kilos = 0;	//Peso de la oferta			
		double precio=0.00;	//Precio de la oferta
		ArrayList<String> listado = new ArrayList<String>(); //Array con la informacion que devolvemos
								
		try{	
			List<Oferta> lista = ventasDataBase.get(iDSesion); //Obtenemos la lista de ventas
						
			Iterator<Oferta> iterador = lista.iterator();
			while (iterador.hasNext()){ //Vamos iterando por las ofertas y las añadimos a la lista
				Oferta oferta = (Oferta) iterador.next();
							
				tipoMercancia = oferta.getTipo();
				precio = oferta.getPrecio();
				kilos = oferta.getKilos();
							
				listado.add(String.valueOf(iDSesion));
				listado.add(String.valueOf(tipoMercancia));
				listado.add(String.valueOf(precio));
				listado.add(String.valueOf(kilos));
				}
			} catch(NoSuchElementException e) {System.out.println();
			} catch(NullPointerException e) {System.out.println();
			} catch(Exception e) {System.out.println();
		}	
		return listado; //Devolvemos la lista de ventas
	}		

}
