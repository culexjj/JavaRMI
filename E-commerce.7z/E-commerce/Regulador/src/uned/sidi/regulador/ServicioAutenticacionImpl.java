
package uned.sidi.regulador;

import java.rmi.RemoteException;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.NoSuchElementException;

import uned.sidi.comun.ServicioAutenticacionInterface;
import uned.sidi.comun.Usuario;



public class ServicioAutenticacionImpl implements ServicioAutenticacionInterface{
	
	/*--------------------------*/
	/* DECLARACION DE VARIABLES */
	/*--------------------------*/
	
	private Map<Integer,Usuario> usuariosDataBase; //Map que registra datos de acceso de los usuarios
	private static int sesion = Math.abs(new Random().nextInt()); //Solo numeros positivos
	
	
	/*--------------------------*/
	/*       CONSTRUCTORES      */
	/*--------------------------*/
	
	protected ServicioAutenticacionImpl() throws RemoteException {
		super();
		usuariosDataBase = new HashMap<Integer,Usuario>();		
	}
	
	
	/*--------------------------*/
	/*    METODOS   INTERFAZ    */
	/*--------------------------*/
	
	/**
	 * Permite obtener la lista de distribuidores o clientes.Utiliza la variable tipo para la clasificación 
	 * de clientes y distribuidores. si tipo es 0 entonces indica que es un distribuidor y si es 1 indica 
	 * que es un cliente
	 * @param tipo. El tipo de usuario
	 * @throws RemoteException
	 */
	@Override
	public synchronized void  listarUsuarios(int tipo) throws RemoteException{
		
		String nombreLista = ""; //Nombre de la lista 
		
		if ( tipo == 0) { 
				nombreLista = "\nListado Distribuidores";
			} else {
				nombreLista = "\nListado Clientes";
			}
		
		System.out.println(nombreLista); //Imprimimos el nombre de la lista
		
		try{
			Iterator<Entry<Integer, Usuario>> iterador = usuariosDataBase.entrySet().iterator();
			while (iterador.hasNext()) { //Vamos iterando por la lista de usuarios registrados
				Map.Entry<Integer, Usuario> usuarios = (Map.Entry<Integer, Usuario>) iterador.next();
				
				int key = usuarios.getKey();				
				Usuario usuario = usuariosDataBase.get(key);
				String nombre = usuario.getNombre();
				int tipo2 = usuario.getTipo();//Obtenemos el tipo del usuario 0|1
				
				if (tipo == tipo2){ //Solo impriminos las entradas que coinciden con el valor de tipo
					System.out.println(String.format("%15s %11s %20s %20s" , "Identificador: ", key, "Nombre de Usuario: ", nombre));
				}	
			}
		} catch(NoSuchElementException e) {System.out.println(e.getMessage());
		} catch(NullPointerException e) {System.out.println(e.getMessage());
		} catch(Exception e) {System.out.println(e.getMessage());
		}
	}
	
	/**
	 * Al salir del sistema establecemos vel alor del atributo activo a false para indicar que no esta logeado
	 * @param iDSesion. el identificador del usuario
	 * @throws RemoteException
	 */
	@Override
	public synchronized void salir(int iDSesion) throws RemoteException {
		Usuario usuario = usuariosDataBase.get(iDSesion);
		usuario.setFlagActivo(false);		
	}
	
	
	/**
	 * Registro de usuario en el servicio de autenticación
	 * Recibe el nombre la clave de acceso y el tipo 
	 * Obtenemos el ID asignado por el servicio de autenticación
	 * @param nombre. el nombre del usuario
	 * @param clave. la clave de usuario
	 * @param  tipo. el tipo del usuario
	 * @return sesion
	 * @throws RemoteException
	 */
	@Override
	public synchronized int registro(String nombre, String clave, int tipo) throws RemoteException {
		
		int sesion = getID(); //Obtenemos el ID del nuevo usuario usando el método privado getID		
		Usuario datosUsuario = new Usuario(nombre, clave, tipo); //Creamos objeto usuario
		usuariosDataBase.put(sesion, datosUsuario);//
		return sesion; //Devolvemos el identificador asignado
	}
	
	
	/**
	 * Baja de un usuario del sistema pasando como parámetro su ID
	 * @param iDSesion. el identificador del usuario
	 * @return el resultado de la operacion
	 * @throws RemoteException
	 */
	
	@Override
	public synchronized boolean bajaSistema(int iDSesion) throws RemoteException {	
		
		if (!usuariosDataBase.containsKey(iDSesion)){ //Verificamos que el ID existe
			return false; //Si no existe devolvemos false
		} else {
			usuariosDataBase.remove(iDSesion); //Si existe lo borramos
			return true; //Devolvemos true si se ha podido borrar el usuario
		}
	}
	
	
	/**
	 * Autenticación de usuario en el servicio de autenticación
	 * Se recupera de usuariosDataBase los datos de usuario de ID pasado como parámetro
	 * y se comprueban con los datos introducidos por el usuario
	 * @param iDSesion. el identificador de  usuario
	 * @param nombre. el nombre del usuario
	 * @param clave. la clave de usuario
	 * @param  tipo. el tipo del usuario
	 * @return el resutado de la operación
	 * @throws RemoteException
	 */
	@Override
	public synchronized boolean login(int iDSesion, String nombre, String clave, int tipo) throws RemoteException {
		
		if (!usuariosDataBase.containsKey(iDSesion)){ //Verificamos que el ID existe
			throw new RuntimeException("USUARIO NO REGISTRADO!!!");
		}
		
		Usuario usuario = usuariosDataBase.get(iDSesion);
		String nombreTmp = usuario.getNombre(); //Nombre registrado
		String claveTmp = usuario.getClave(); //Clave registrada
		int tipoTmp = usuario.getTipo(); //Tipo de usuario
		
		/* control para evitar que cliente puede iniciar sesión como si fuese un distribuidor y viceversa*/
		if (tipoTmp != tipo) {
			return false; //Si es tipo del usuario registrado es distinto al tipo prederteminado [0=Distribuidor | 1= cliente] 
		}
				
		boolean check1 = false; //Control nombre usuario
		boolean check2 = false; //Control clave de acceso
		
		check1 = nombre.equals(nombreTmp); //control nombre usuario pasado como paramentro con el registrado
		check2 = clave.equals(claveTmp); //control clave de acceso pasada como paramentro con la registrada
			
		if (check1 && check2) { 
			usuario.setFlagActivo(true);//Si la validacion es correcta valor del atributo activo se establece a true para indicar que esta logeado
			return true; //Si el nombre usuario y la clave de acceso son correctos devolvemos true		
		}
		
		usuario.setFlagActivo(false); //Si no es correcto no se ha iniciado la sesion
		return false; //si no lo son devolvemos false
	}
	
	
	/**
	 * Devuelve el valor del flag activo de un usuario pasado como parámetro (el ID)
	 * @param iDSesion. el identificador de usuario
	 * @return activo. el valor del flag activo
	 * @throws RemoteException
	 */
	@Override
	public synchronized boolean getFlagActivo(int iDSesion) throws RemoteException {
		
		boolean activo = false; //Flag indicador sesion activa
			
		try {
			Usuario datosUser = usuariosDataBase.get(iDSesion);
			activo = datosUser.getFlagActivo();	
		} catch(NullPointerException e) { //Si no existe el identificador el usuario no se ha registrado
			System.out.println("");		
		}
		
		return activo;
	}
	
	
	/**
	 * Devuelve el nombre de un usuario pasado como parámetro (el ID)
	 * @param iDSesion. el identificador de usuario
	 * @return nombre
	 * @throws RemoteException
	 */
	@Override
	public synchronized String getDatosNombre(int iDSesion) throws RemoteException {
		String nombre; //Nombre del usuario
		Usuario datosUser = usuariosDataBase.get(iDSesion);
		nombre = datosUser.getNombre();	//Obtenemos el nombre	 
		return nombre;
	}

	
	/**
	 * Devuelve la clave de un usuario pasado como parámetro (el ID)
	 * @param iDSesion. el identificador de usuario
	 * @return clave
	 * @throws RemoteException
	 */
	@Override
	public synchronized String getDatosClave(int iDSesion) throws RemoteException {
		String clave; //Clave del usuario
		Usuario datosUser = usuariosDataBase.get(iDSesion);
		clave = datosUser.getClave(); //Obtenemos la clave	 	
		return clave;
	}
	
		
	
	/*--------------------------*/
	/*    METODOS   PRIVADOS    */
	/*--------------------------*/
	
	/**
	* Método encargado de devolver el Id único de usuario, es un número secuencial generado a partir de un número aleatorio
	* @return el identificador de usuario
	*/
	private static synchronized int getID(){
		return ++sesion;
	}
}
