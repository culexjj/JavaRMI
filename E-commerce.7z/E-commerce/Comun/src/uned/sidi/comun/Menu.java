package uned.sidi.comun;

import java.util.InputMismatchException;
import java.util.Scanner;




public class Menu {
	
	/**
	 * Menu común para distribuidores y clientes
	 * @return opcion. Opcion seleccionada
	 */
	public static synchronized int menu1(){
		Boolean control = true; //Condicion de salida bucle do-while
		int opcion = 0; //Opcion seleccionada.
		
			do {
				System.out.println();
				System.out.println("Menu numero 1");
			    System.out.println("1-Registrar un nuevo usuario.");
			    System.out.println("2-Autenticarse en el sistema (hacer login.)");
			    System.out.println("3-Salir.");
				    
		    try{
			    @SuppressWarnings("resource")
		    	Scanner lecturaConsola = new Scanner(System.in); //Objeto Scanner
				opcion = lecturaConsola.nextInt();
				} catch (InputMismatchException e){ //Control formato
				   	System.out.println("Por favor, usar solo numeros!");
				}
				    
				switch (opcion) {
					case 1:
						control = false;
				        break;
				    case 2:
				    	control = false;
				        break;
				    case 3:
				        control = false;
				        break;
				    default:
				        System.out.println("Opcion Incorrecta!");
				        System.out.println("");
				    }
				} while (control);
			
		return opcion;				
	}
	
	
	/**
	 * Menu distinto para distribuidores y clientes según valor variable Tipo
	 * @param tipo. el tipo de usuario 
	 * @return opcion. Opcion seleccionada
	 */
	public static synchronized int menu2(int tipo){
		Boolean control = true; //Condicion de salida bucle do-while
		int opcion = 0; //Opcion seleccionada.
		
		if (tipo==0){ //distribuidores
			do {
				System.out.println();
				System.out.println("Menu numero 2");
			    System.out.println("1-Introducir oferta.");
			    System.out.println("2-Quitar oferta.");
				System.out.println("3-Mostrar ventas.");
				System.out.println("4-Darse de baja en el sistema.");				
			    System.out.println("5-Salir.");
				    
		    try{
			    @SuppressWarnings("resource")
		    	Scanner lecturaConsola = new Scanner(System.in); //Objeto Scanner
				opcion = lecturaConsola.nextInt();
				} catch (InputMismatchException e){ //Control formato
				   	System.out.println("Por favor, usar solo numeros!");
				}
				    
				switch (opcion) {
					case 1:
						control = false;
				        break;
				    case 2:
				    	control = false;
				        break;
				    case 3:
				        control = false;
				        break;
					case 4:
				    	control = false;
				        break;
					case 5:
				        control = false;
				        break;
				    default:
				        System.out.println("Opcion Incorrecta!");
				        System.out.println("");
				    }
				} while (control);
			
		return opcion;
		
		} else if (tipo==1 ){ //Clientes		
			do {
				System.out.println();
				System.out.println("Menu numero 2");
			    System.out.println("1-Introducir demanda.");
			    System.out.println("2-Recibir ofertas.");
				System.out.println("3-Comprar mercancias.");
				System.out.println("4-Darse de baja en el sistema.");	
			    System.out.println("5-Salir.");
			    System.out.println("");
				    
		    try{
			    @SuppressWarnings("resource")
		    	Scanner lecturaConsola = new Scanner(System.in); //Objeto Scanner
				opcion = lecturaConsola.nextInt();
				} catch (InputMismatchException e){ //Control formato
				   	System.out.println("Por favor, usar solo numeros!");
				}
				switch (opcion) {
					case 1:
						control = false;
				        break;
				    case 2:
				    	control = false;
				        break;
				    case 3:
				        control = false;
				        break;
					case 4:
				    	control = false;
				        break;
					case 5:
						control = false;
				        break;
				    default:
				        System.out.println("Opcion Incorrecta!");
				        System.out.println("");
				    }
				} while (control);
		return opcion;
		} else {
			System.out.println("Clasificacion de usuario incorrecta. Exit code = 2");
	        System.exit(2);
		}
		return opcion;
	}
	
	
	/**
	 * Menu regulador
	 * @return opcion. Opcion seleccionada
	 */
	public static synchronized int menu3(){
		Boolean control = true; //Condicion de salida bucle do-while
		int opcion = 0; //Opcion seleccionada.
		
			do {
				System.out.println();
				System.out.println("Menu Regulador");
			    System.out.println("1-Listar ofertas actuales.");
			    System.out.println("2-Listar demandas actuales");
			    System.out.println("3-Listar clientes");
			    System.out.println("4-Listar distribuidores");
			    System.out.println("5-Salir.");
				    
		    try{
			    @SuppressWarnings("resource")
		    	Scanner lecturaConsola = new Scanner(System.in); //Objeto Scanner
				opcion = lecturaConsola.nextInt();
				} catch (InputMismatchException e){ //Control formato
				   	System.out.println("Por favor, usar solo numeros!");
				}
				    
				switch (opcion) {
					case 1:
						control = false;
				        break;
				    case 2:
				    	control = false;
				        break;
				    case 3:
				    	control = false;
				        break;
				    case 4:
				    	control = false;
				        break;
				    case 5:
				        control = false;
				        break;
				    default:
				        System.out.println("Opcion Incorrecta!");
				        System.out.println("");
				    }
				} while (control);
		return opcion;				
	}
	
	
	/**
	 * Metodo solicita el nombre de un usuario  y lo devuelve como un String
	 * @return nombreUsuario: el nombre de usuario introducido
	 */
	
	public static synchronized String nombreUsuario() {
		
		@SuppressWarnings("resource")
		Scanner escaner = new Scanner (System.in); //Creación de un objeto Scanner
		String nombreUsuario= ""; //Nombre usuario
		System.out.println ("Por favor introduzca su nombre de usuario:");			    
	    nombreUsuario = escaner.nextLine ().trim(); //Eliminamos espacios en blanco
	    
		return nombreUsuario;
	}
	
	
	/**
	 * Metodo solicita la clave de acceso de un usario  y lo devuelve como un String
	 * @return clave: la clave de usuario introducida
	 */
	
	public static synchronized String claveAcceso() {
		
		@SuppressWarnings("resource")
		Scanner escaner = new Scanner (System.in); //Creación de un objeto Scanner
		String clave= ""; //Clave usuario
		System.out.println ("Por favor introduzca su clave de acceso:");		    
	    clave = escaner.nextLine ().trim(); //Eliminamos espacios en blanco
	    
		return clave;	
	}
	
	
	/**
	 * Metodo solicita el identificador de un usuario  y lo devuelve como un int
	 * @return id:El identificar del usuario introducido
	 */
	
	public static synchronized int identificador() {
		
		int id = 0; //Identificador
		try {
			System.out.println ("Por favor introduzca el identificador:");
			@SuppressWarnings("resource")
			Scanner escaner = new Scanner (System.in); //Creacion de un objeto Scanner
			id = escaner.nextInt();
			} catch (InputMismatchException e){ //Control formato
				System.out.println("Formato incorrecto!");
			}
		return id;
	}
	
	
	/**
	 * Metodo que solicita el numero de oferta selecciona y lo devuelve como un int
	 * @return numero. El numero de oferta introducido
	 */
	public static synchronized int numeroOferta() {
		int numero = 0; //Numero
		try {
			System.out.println ("Por favor introduzca el numero de la oferta:");
			@SuppressWarnings("resource")
			Scanner escaner = new Scanner (System.in); //Creacion de un objeto Scanner
			numero = escaner.nextInt(); 
			} catch (InputMismatchException e){ //Control formato
				System.out.println("Formato incorrecto!");
			}
		return numero;
	}
	
	
	/**
	 * Metodo que solicita al usuario el tipo de mercancia al realizar una demanda/�lo vamos a usar tambien con las ofertas
	 * @return valor. El tipo elegido como un string
	 */
	
	public static synchronized String introducirTipo() {
		Boolean control = true; //Se usa como condicion de salida del bucle do-while
		Mercancia tipoMercancia = Mercancia.TOMATES ; //Inicializamos la variable de la clase enumerada Mercancia
		String mercancia; //
		int eleccion = 0; //Tipo producto de la oferta	
		@SuppressWarnings("resource")
		Scanner escaner = new Scanner (System.in); //Creación de un objeto Scanner
		
		/* Eleccion tipo Mercancia */
		do { 
			int contador = 0; //Variable usadada para numerar las distintas opciones
			System.out.println ("Por favor introduzca el tipo de mercancia:");	
			
			for (Mercancia tipo : Mercancia.values()){ //Obtenemos los valores de la clase enumerada Mercancia y los mostramos por pantalla
				contador++;
		        System.out.println(contador + ":" + tipo);
		    }
								
			mercancia = escaner.nextLine ().trim(); //Eliminamos espacios en blanco
					
			try { //Controlamos el formato de la respuesta es numerico
				eleccion = Integer.parseInt(mercancia); //Verificamos que los datos introducidos son numero entero
			} catch (NumberFormatException e){
				System.out.println("Por favor usar solo numeros!");
			} 
			
			switch (eleccion) {
				case 1:
					tipoMercancia = Mercancia.TOMATES;
					control = false;
					break;
				case 2:
					tipoMercancia = Mercancia.LIMONES;
					control = false;
					break;
			    case 3:
			    	tipoMercancia = Mercancia.NARANJAS;
			    	control = false;
			        break;			        
				case 4:
					tipoMercancia = Mercancia.FRESAS;
					control = false;
			        break;
				case 5:
					tipoMercancia = Mercancia.PLATANOS;
					control = false;
			        break;
				case 6:
					tipoMercancia = Mercancia.MELONES;
					control = false;
			        break;
				case 7:
					tipoMercancia = Mercancia.SANDIAS;
					control = false;
			        break;
			    default:
			        System.out.println("Opcion Incorrecta!");
			        System.out.println("");
			    }
	
		} while (control);		
		
		String valor = tipoMercancia.toString(); //pasamos el valor enumerado a string
		
		return valor; //El tipo de mercancia seleccionado
	}
	
	
	
	/**
	 * Metodo que solicita el precio de una oferta
	 * @return precio. El precio de la oferta introducido
	 */
	public static synchronized double precioOferta(){
	
		Boolean control = true; //Se usa como condicion de salida del bucle do-while
		double precio = 0; //Precio de la oferta
		@SuppressWarnings("resource")
		Scanner escaner = new Scanner (System.in); //Creacion de un objeto Scanner
		
		do {
			System.out.println ("Por favor introduzca el precio:");
			System.out.println ("Ejemplo: 20.53");
			String precioIn= "";
			precioIn = escaner.nextLine ().trim(); //Eliminamos espacios en blanco
		
			try { 
				precio = Double.parseDouble(precioIn); //Controlamos el formato de la respuesta
				
				if (precio <= 0.00) {
					System.out.println("\nPrecio incorrecto! (debe ser mayor de 0)");
					control = true;
				} else {
					control = false;
				}
				
			} catch (NumberFormatException e){ 
				System.out.println("Por favor use el formato del ejemplo!");
			}			
		} while (control);	
		
		return precio;
		
	}
	
	
	/**
	 * Metodo que solicita el peso de una oferta
	 * @return kilos. El peso introducido.
	 */
	public static synchronized int pesoOferta(){
		
		Boolean control = true; //Se usa como condicion de salida del bucle do-while
		int kilos = 0; //Peso de la oferta
		@SuppressWarnings("resource")
		Scanner escaner = new Scanner (System.in); //Creacion de un objeto Scanner
		
		do {
			System.out.println ("Por favor introduzca el numero de kilos:");
			System.out.println ("Ejemplo: 115");
			String kilosIn= "";
			kilosIn = escaner.nextLine ().trim(); //Eliminamos espacios en blanco
	
			try { 
				kilos = Integer.parseInt(kilosIn); //Controlamos el formato de la respuesta
				
				if (kilos <= 0) {
					System.out.println("\nPeso incorrecto! (debe ser mayor de 0)");
					control = true;
				} else {
					control = false;
				}
				
			} catch (NumberFormatException e){
				System.out.println("Por favor use el formato del ejemplo!");
			}
		} while (control);	
		
		return kilos; 
	}
}