package uned.sidi.comun;


public enum Mercancia {

	    TOMATES,
	    LIMONES,
	    NARANJAS,
	    FRESAS,
	    PLATANOS,
	    MELONES,
	    SANDIAS;
}
