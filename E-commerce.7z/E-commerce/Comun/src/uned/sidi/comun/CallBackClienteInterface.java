package uned.sidi.comun;

import java.rmi.Remote;
import java.rmi.RemoteException;


public interface CallBackClienteInterface extends Remote{
	
	public void avisoRegistroOferta(String mensaje) throws RemoteException; //Mensaje de aviso al cliente. Un distribuidor ha registrado una oferta que el cliente demanda
}
