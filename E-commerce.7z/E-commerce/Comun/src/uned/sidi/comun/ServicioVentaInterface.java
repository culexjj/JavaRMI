package uned.sidi.comun;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.ArrayList;
//import java.util.List;


public interface ServicioVentaInterface extends Remote{
	
	public boolean registarVenta(Integer Id, int numero) throws RemoteException; //Registrar una venta en la BBDD del distribuidor
	public ArrayList<String> listarVentasToArray(int id) throws RemoteException; //

}
