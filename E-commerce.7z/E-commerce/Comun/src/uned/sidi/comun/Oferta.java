package uned.sidi.comun;

import java.io.Serializable;



public class Oferta implements Serializable{
	
	/*--------------------------*/
	/* DECLARACION DE VARIABLES */
	/*--------------------------*/
	
	private static final long serialVersionUID = 1288223977112786553L;
	private Mercancia tipo; //Tipo de la Mercancia
	private Double precio; //Precio de la oferta
	private Integer kilos; //Peso de la oferta


	/*--------------------------*/
	/*       CONSTRUCTORES      */
	/*--------------------------*/
	
	public Oferta (Mercancia tipo, Double precio,Integer kilos){
		this.tipo = tipo;
		this.precio = precio;
		this.kilos = kilos;
	}
	
	
	/*--------------------------*/
	/*    METODOS   PUBLICOS    */
	/*--------------------------*/
	
	/**
	 * @return el objeto oferta
	 */
	public Oferta getOferta(){
		return this;
	}
	
	/**
	 * @return el Tipo (clase enumerada Mercancia) de la oferta
	 */
	public Mercancia getTipo() {
		return tipo;
	}
	
	/**
	 * @return el precio de la oferta
	 */
	public double getPrecio(){
		return precio;
	}
	/**
	 * @return el peso de la oferta
	 */
	public int getKilos(){
		return kilos;
	} 
}
