package uned.sidi.comun;

import java.rmi.Remote;
import java.rmi.RemoteException;


public interface ServicioAutenticacionInterface extends Remote{
	
	public void listarUsuarios (int tipo) throws RemoteException; //Listado de clientes y distribuidores registrados
	public void salir(int iDSesion) throws RemoteException; //Al salir del sistema establecemos vel alor del atributo activo a false para indicar que no esta logeado
	public int registro(String nombre, String clave, int tipo) throws RemoteException; //Registro de usuario en el servicio de autenticacion
	public boolean bajaSistema(int iDSesion) throws RemoteException; //Baja de usuario de la BBDD del servicio de autenticacion
	public boolean login(int id, String username, String password, int tipo) throws RemoteException; //Autenticacion de usuario en el servicio de autenticacion. Devuelve un boolean indicando si el login ha sido exitoso o no
	public boolean getFlagActivo(int iDSesion) throws RemoteException; ////Devuelve el flag activo de un usuario. Pasando como parametro su ID
	public String getDatosNombre(int iDSesion) throws RemoteException; //Devuelve el nombre de un usuario. Pasando como parametro su ID
	public String getDatosClave(int iDSesion) throws RemoteException; //Devuelve la clave de un usuario. Pasando como parametro su ID
}
