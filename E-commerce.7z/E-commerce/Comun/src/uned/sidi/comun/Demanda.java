package uned.sidi.comun;

import java.io.Serializable;


public class Demanda implements Serializable{
	
	/*--------------------------*/
	/* DECLARACION DE VARIABLES */
	/*--------------------------*/

	private static final long serialVersionUID = 1212223977112786553L;
	private Mercancia tipo; //Tipo de la Mercancia

	
	/*--------------------------*/
	/*       CONSTRUCTORES      */
	/*--------------------------*/
	
	public Demanda (Mercancia tipo){
		this.tipo = tipo;
	}
	
	
	/*--------------------------*/
	/*    METODOS   PUBLICOS    */
	/*--------------------------*/
	
	/**
	 * @return el objeto demanda
	 */
	public Demanda getDemanda(){
		return this;
	}
	
	/**
 	 * @return el Tipo (clase enumerada Mercancia) de la demanda 
	 */
	public Mercancia getTipo(){
		return tipo;
	}
}
